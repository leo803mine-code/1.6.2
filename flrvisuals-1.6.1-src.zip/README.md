# FLR Visuals

Клиентский мод для NeoForge 1.21.1: крылья, нимб, плащ, шапки, питомцы, цветное небо,
Auto Swap, Armor Alert, поддержка геймпада, переключатель оффлайн-аккаунтов,
чёрное меню и экраны загрузки в стиле PlayStation. Язык: English / Русский.

## Сборка
- Автоматически: каждый push запускает GitHub Actions (`.github/workflows/build.yml`).
  Готовый `.jar` лежит во вкладке **Actions → последний запуск → Artifacts → flrvisuals**.
- Локально: Java 21 и `gradle build` (jar появится в `build/libs/`).

## Установка
Положите jar в папку `mods` (NeoForge 1.21.1, клиент).
