package dev.flr.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Крылья/нимб/плащ. Все детали крепятся к ЧАСТЯМ МОДЕЛИ (body/head) через translateAndRotate,
 * поэтому они сами следуют за приседанием и наклоном.
 */
public class CosmeticsLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation WHITE = ResourceLocation.fromNamespaceAndPath(FlrVisuals.MOD_ID, "textures/misc/white.png");
    /** Angel, Demon, Dark, Crystal */
    private static final int[] PALETTE = {0xFFE9E9F2, 0xFFC0304A, 0xFF5B4BB0, 0xFF8FD8EA};
    private static final Map<UUID, WingModel.State> STATES = new HashMap<>();
    private static final float[] Q = new float[12];
    private static final int[] C = new int[4];

    public CosmeticsLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer p, float limb, float limbAmt,
                       float pt, float age, float yaw, float pitch) {
        if (!Config.master || p.isSpectator()) return;
        if (p.isInvisible() && !Config.showInvisible) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        boolean self = p == mc.player;
        double d2 = mc.player.distanceToSqr(p);
        if (!self && (!Config.others || d2 > (double) Config.maxDistance * Config.maxDistance
                || !GameEvents.ALLOWED.contains(p.getUUID()))) return;
        double lodD = Config.lodDistance;
        boolean lod = d2 > lodD * lodD || (Config.autoPerf && Config.fps < 35);
        int theme = Config.color();
        int lit = LightTexture.pack(Math.max(LightTexture.block(light), 7), LightTexture.sky(light));
        boolean sneak = p.isCrouching();

        if (Config.wings) wings(ps, buf, p, limbAmt, theme, lit, lod, sneak);
        if (Config.cape) cape(ps, buf, limbAmt, age, theme, lit, lod, sneak);
        if (Config.halo) halo(ps, buf, age, theme, lod);
        if (Config.hat > 0) hat(ps, buf, age, lit);
        if (Config.pet > 0 && (self || !lod)) pet(ps, buf, limb, limbAmt, age, yaw, pitch, lit);
    }

    private void wings(PoseStack ps, MultiBufferSource buf, AbstractClientPlayer p, float limbAmt, int theme, int lit,
                       boolean lod, boolean sneak) {
        WingModel.State st = STATES.computeIfAbsent(p.getUUID(), k -> new WingModel.State());
        long now = System.nanoTime();
        float dt = st.lastNanos == 0 ? 0.016f : Math.min(0.1f, (now - st.lastNanos) / 1e9f);
        st.lastNanos = now;
        st.lastSeenMs = now / 1_000_000L;
        boolean air = !p.onGround() && !p.isInWater();
        float mv = Math.min(1f, limbAmt);
        float tSpread = (air || p.isFallFlying()) ? 1f : sneak ? 0.15f : 0.3f + 0.35f * mv;
        float tAmp = air ? 0.9f : 0.12f + 0.2f * mv;
        float tSpeed = (air ? 6f : 1.5f + 2f * mv) * (float) Config.speed;
        st.update(dt, tSpread, tAmp, tSpeed, sneak ? 1f : 0f);
        if (STATES.size() > 64) STATES.values().removeIf(s -> now / 1_000_000L - s.lastSeenMs > 10_000L);

        int type = Config.wingStyle;
        int accent = switch (Config.wingColorMode) {
            case 1 -> theme;
            case 2 -> Config.hsb(Config.wingHue, Config.wingSat, Config.wingBri);
            default -> PALETTE[Math.max(0, Math.min(3, type))];
        };
        WingModel.optAlpha = (float) Config.wingAlpha;
        WingModel.optFlap = (float) Config.wingFlap;
        WingModel.optAngle = (float) Math.toRadians(Config.wingAngle);
        WingModel.optGap = (float) Config.wingGap;
        WingModel.optY = (float) Config.wingHeight;
        WingModel.optZ = (float) Config.wingDepth;

        float size = (float) Config.wingSize;
        ps.pushPose();
        getParentModel().body.translateAndRotate(ps);
        VertexConsumer vc = buf.getBuffer(RenderType.entityTranslucent(WHITE));
        PoseStack.Pose pose = ps.last();
        WingModel.Sink sink = (xyz, argb) -> emit(vc, pose, xyz, argb, false, lit);
        WingModel.build(type, -1, size, st, accent, lod, sink);
        WingModel.build(type, 1, size, st, accent, lod, sink);
        ps.popPose();
    }

    /** Плащ: узкий и вытянутый, чуть сужается книзу; цвет — тема / свой / градиент. */
    private void cape(PoseStack ps, MultiBufferSource buf, float limbAmt, float age, int theme, int lit, boolean lod,
                      boolean sneak) {
        ps.pushPose();
        getParentModel().body.translateAndRotate(ps);
        VertexConsumer vc = buf.getBuffer(RenderType.entityTranslucent(WHITE));
        PoseStack.Pose pose = ps.last();
        float bend = Mth.clamp(limbAmt * 0.3f + (sneak ? 0.12f : 0f), 0f, 0.45f);
        float sway = (float) Math.sin(age * 0.08f) * 0.03f * (float) Config.capeSway;
        float wTop = 0.16f * (float) Config.capeWidth, wBot = 0.12f * (float) Config.capeWidth;
        float len = 1.15f * (float) Config.capeLength;
        int segs = lod ? 4 : 8;

        int top, bot;
        if (Config.capeColorMode == 1) top = Config.hsb(Config.capeHue, Config.capeSat, Config.capeBri);
        else if (Config.capeColorMode == 2) top = Config.hsb(Config.capeHue, Config.capeSat, Config.capeBri);
        else top = theme;
        if (Config.capeColorMode == 2) bot = Config.hsb(Config.capeHue2, Config.capeSat, Config.capeBri);
        else bot = shade(top, 0.62f, 255);

        for (int j = 0; j < segs; j++) {
            float f0 = j / (float) segs, f1 = (j + 1) / (float) segs;
            float y0 = 0.02f + f0 * len, y1 = 0.02f + f1 * len;
            float z0 = 0.2f + bend * f0 * f0 + sway * f0, z1 = 0.2f + bend * f1 * f1 + sway * f1;
            float w0 = Mth.lerp(f0, wTop, wBot), w1 = Mth.lerp(f1, wTop, wBot);
            set(Q, 0, -w0, y0, z0); set(Q, 3, w0, y0, z0); set(Q, 6, w1, y1, z1); set(Q, 9, -w1, y1, z1);
            int ca = shade(WingModel.mixArgb(top, bot, f0), 1f, 235), cb = shade(WingModel.mixArgb(top, bot, f1), 1f, 235);
            C[0] = ca; C[1] = ca; C[2] = cb; C[3] = cb;
            emit(vc, pose, Q, C, false, lit);
        }
        ps.popPose();
    }

    /**
     * Нимб. Рисуется тем же render type, что и крылья/плащ (они гарантированно видны и на самом игроке),
     * с полной яркостью и без отсечения граней, плюс мягкое внешнее свечение.
     */
    private void hat(PoseStack ps, MultiBufferSource buf, float age, int lit) {
        ps.pushPose();
        getParentModel().head.translateAndRotate(ps);
        Pets.begin(ps, buf.getBuffer(RenderType.entityTranslucent(WHITE)), lit);
        Pets.hat(Config.hat, age);
        ps.popPose();
    }

    /** Питомец стоит справа от игрока и повторяет его поворот; ноги двигаются от скорости ходьбы. */
    private void pet(PoseStack ps, MultiBufferSource buf, float limb, float limbAmt, float age, float yaw, float pitch, int lit) {
        ps.pushPose();
        ps.translate(0, 1.501, 0);
        ps.scale(-1, -1, 1);
        ps.translate(0.95, 0, -0.1);
        float sz = (float) Config.petSize;
        ps.scale(sz, sz, sz);
        Pets.begin(ps, buf.getBuffer(RenderType.entityTranslucent(WHITE)), lit);
        Pets.pet(Config.pet, age, limb, limbAmt, yaw, pitch);
        ps.popPose();
    }

    private void halo(PoseStack ps, MultiBufferSource buf, float age, int theme, boolean lod) {
        ps.pushPose();
        getParentModel().head.translateAndRotate(ps);
        VertexConsumer vc = buf.getBuffer(RenderType.entityTranslucent(WHITE));
        PoseStack.Pose pp = ps.last();
        int hc = Config.haloColorMode == 1 ? Config.hsb(Config.haloHue, Config.haloSat, Config.haloBri) : theme;
        float y = -0.64f - (float) Config.haloHeight + (float) Math.sin(age * 0.1f) * 0.02f;
        float sz = (float) Config.haloSize;
        float r0 = 0.20f * sz, r1 = 0.29f * sz, r2 = 0.36f * sz;
        int n = lod ? 12 : 24;
        int full = LightTexture.FULL_BRIGHT;
        int cIn = shade(hc, 1f, 245), cOut = shade(hc, 0.85f, 245), gIn = shade(hc, 0.85f, 120), gOut = shade(hc, 0.7f, 0);
        for (int i = 0; i < n; i++) {
            double a0 = i * Math.PI * 2 / n, a1 = (i + 1) * Math.PI * 2 / n;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            ring(vc, pp, c0, s0, c1, s1, r0, r1, y, cIn, cOut, full);
            ring(vc, pp, c0, s0, c1, s1, r1, r2, y, gIn, gOut, full);
        }
        ps.popPose();
    }

    private static void ring(VertexConsumer vc, PoseStack.Pose pp, float c0, float s0, float c1, float s1, float ra, float rb,
                             float y, int cA, int cB, int light) {
        set(Q, 0, ra * c0, y, ra * s0); set(Q, 3, rb * c0, y, rb * s0);
        set(Q, 6, rb * c1, y, rb * s1); set(Q, 9, ra * c1, y, ra * s1);
        C[0] = cA; C[1] = cB; C[2] = cB; C[3] = cA;
        emit(vc, pp, Q, C, false, light);
    }

    private static void set(float[] a, int o, float x, float y, float z) {
        a[o] = x; a[o + 1] = y; a[o + 2] = z;
    }

    private static int shade(int argb, float k, int alpha) {
        int r = Math.min(255, (int) ((argb >> 16 & 255) * k)), g = Math.min(255, (int) ((argb >> 8 & 255) * k)), b = Math.min(255, (int) ((argb & 255) * k));
        return alpha << 24 | r << 16 | g << 8 | b;
    }

    private static void emit(VertexConsumer vc, PoseStack.Pose pose, float[] v, int[] argb, boolean add, int light) {
        float ax = v[3] - v[0], ay = v[4] - v[1], az = v[5] - v[2];
        float bx = v[6] - v[0], by = v[7] - v[1], bz = v[8] - v[2];
        float nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
        float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (len < 1e-6f) { nx = 0; ny = 0; nz = 1; } else { nx /= len; ny /= len; nz /= len; }
        if (nz < 0) { nx = -nx; ny = -ny; nz = -nz; }
        for (int k = 0; k < 4; k++) {
            VertexConsumer b = vc.addVertex(pose.pose(), v[k * 3], v[k * 3 + 1], v[k * 3 + 2]).setColor(argb[k]);
            if (!add) b.setUv(0f, 0f).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose, nx, ny, nz);
        }
    }
}
