package dev.flr.visuals;

import java.awt.Color;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import net.minecraft.client.Minecraft;
import net.minecraft.client.ParticleStatus;
import net.neoforged.fml.loading.FMLPaths;

public final class Config {
    // ---- функции ----
    public static boolean master = true, wings = true, halo = true, cape = false, ambient = false, aura = false,
            trail = false, hitSparks = false, others = true, hud = true, autoPerf = true,
            autoSwap = true, armorAlert = true, showInvisible = false, gamepad = true;
    public static int theme = 0, wingStyle = 0, particleType = 0, particleBudget = 40, maxDistance = 48,
            swapHeight = 10, armorPercent = 10, maxPlayers = 12, lodDistance = 24, msgMode = 0,
            wingColorMode = 0, haloColorMode = 0, capeColorMode = 0, lang = 0;
    public static double scale = 1.0, speed = 1.0, hue = 0.55, themeSat = 0.65, fogDensity = 0.0, fogTint = 0.0,
            // крылья
            wingSize = 1.0, wingAngle = 0.0, wingGap = 0.0, wingHeight = 0.0, wingDepth = 0.0, wingFlap = 1.0, wingAlpha = 1.0,
            wingHue = 0.55, wingSat = 0.65, wingBri = 1.0,
            // нимб
            haloSize = 1.0, haloHeight = 0.0, haloHue = 0.12, haloSat = 0.6, haloBri = 1.0,
            // плащ
            capeLength = 1.0, capeWidth = 1.0, capeSway = 1.0, capeHue = 0.75, capeHue2 = 0.55, capeSat = 0.7, capeBri = 0.9;
    public static boolean sky = false, menuStyle = true;
    public static int skyMode = 2, hat = 0, pet = 0;
    public static double skyHue = 0.75, skyAlpha = 0.55, petSize = 1.0;
    public static transient int fps = 60;

    public static final String[] THEME_NAMES = {"Aqua", "Violet", "Rose", "Gold", "Rainbow", "Custom"};
    public static final int[] THEME_COLORS = {0x35E0FF, 0xA06BFF, 0xFF5C9E, 0xFFC94D};
    public static final String[] WING_NAMES = WingModel.NAMES;
    public static final String[] PARTICLE_NAMES = {"End rod", "Heart", "Glow", "Snow", "Spark", "Dust"};
    public static final String[] LANG_NAMES = {"Auto", "English", "Русский"};
    public static final String[] HAT_NAMES = {"None", "New Year hat"};
    public static final String[] PET_NAMES = {"None", "Rabbit", "Cat", "Jaguar", "Penguin", "Broken door"};
    public static final String[] SKY_NAMES = {"Theme", "Custom", "Rainbow"};
    public static final String[] MSG_NAMES = {"Toast", "Chat", "Off"};
    public static final String[] WING_COLOR_NAMES = {"Preset", "Theme", "Custom"};
    public static final String[] COLOR_NAMES = {"Theme", "Custom"};
    public static final String[] CAPE_COLOR_NAMES = {"Theme", "Custom", "Gradient"};

    private static final Map<String, Object> DEFAULTS = new HashMap<>();

    static {
        for (Field f : fields()) {
            try {
                DEFAULTS.put(f.getName(), f.get(null));
            } catch (Exception ignored) {
            }
        }
    }

    /** Основной цвет темы, ARGB. */
    public static int color() {
        int rgb;
        if (theme < THEME_COLORS.length) rgb = THEME_COLORS[theme];
        else if (theme == 4) rgb = Color.HSBtoRGB((System.currentTimeMillis() % 8000L) / 8000f * (float) Math.max(speed, 0.2), 0.6f, 1f);
        else rgb = Color.HSBtoRGB((float) hue, (float) themeSat, 1f);
        return 0xFF000000 | (rgb & 0xFFFFFF);
    }

    public static int hsb(double h, double s, double b) {
        return 0xFF000000 | (Color.HSBtoRGB((float) h, (float) s, (float) b) & 0xFFFFFF);
    }

    public static int effectiveBudget() {
        int b = particleBudget;
        if (autoPerf && fps < 40) b /= 3;
        try {
            if (Minecraft.getInstance().options.particles().get() == ParticleStatus.MINIMAL) b /= 2;
        } catch (Exception ignored) {
        }
        return b;
    }

    public static void reset() {
        for (Field f : fields()) {
            Object d = DEFAULTS.get(f.getName());
            if (d == null) continue;
            try {
                f.set(null, d);
            } catch (Exception ignored) {
            }
        }
        save();
    }

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("flrvisuals.properties");
    }

    private static Field[] fields() {
        return java.util.Arrays.stream(Config.class.getDeclaredFields()).filter(f -> {
            int m = f.getModifiers();
            return Modifier.isStatic(m) && !Modifier.isFinal(m) && !Modifier.isTransient(m);
        }).toArray(Field[]::new);
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    public static void load() {
        Path p = file();
        if (!Files.exists(p)) return;
        Properties pr = new Properties();
        try (Reader r = Files.newBufferedReader(p)) {
            pr.load(r);
        } catch (Exception e) {
            return;
        }
        for (Field f : fields()) {
            String v = pr.getProperty(f.getName());
            if (v == null) continue;
            try {
                v = v.trim();
                if (f.getType() == boolean.class) f.setBoolean(null, Boolean.parseBoolean(v));
                else if (f.getType() == int.class) f.setInt(null, Integer.parseInt(v));
                else if (f.getType() == double.class) f.setDouble(null, Double.parseDouble(v));
            } catch (Exception ignored) {
            }
        }
        // миграция со старых версий
        String wt = pr.getProperty("wingTint");
        if (wt != null && pr.getProperty("wingColorMode") == null && Boolean.parseBoolean(wt.trim())) wingColorMode = 1;
        String at = pr.getProperty("autoTotem");
        if (at != null && pr.getProperty("autoSwap") == null) autoSwap = Boolean.parseBoolean(at.trim());

        theme = clamp(theme, 0, THEME_NAMES.length - 1);
        wingStyle = clamp(wingStyle, 0, WingModel.TYPES - 1);
        particleType = clamp(particleType, 0, PARTICLE_NAMES.length - 1);
        msgMode = clamp(msgMode, 0, MSG_NAMES.length - 1);
        wingColorMode = clamp(wingColorMode, 0, 2);
        haloColorMode = clamp(haloColorMode, 0, 1);
        capeColorMode = clamp(capeColorMode, 0, 2);
        lang = clamp(lang, 0, 2);
        hat = clamp(hat, 0, HAT_NAMES.length - 1);
        pet = clamp(pet, 0, PET_NAMES.length - 1);
        skyMode = clamp(skyMode, 0, 2);
        swapHeight = clamp(swapHeight, 5, 20);
        armorPercent = clamp(armorPercent, 5, 50);
        maxPlayers = clamp(maxPlayers, 1, 64);
        lodDistance = clamp(lodDistance, 8, 64);
    }

    public static void save() {
        Properties pr = new Properties();
        for (Field f : fields()) {
            try {
                pr.setProperty(f.getName(), String.valueOf(f.get(null)));
            } catch (Exception ignored) {
            }
        }
        try (Writer w = Files.newBufferedWriter(file())) {
            pr.store(w, "FLR Visuals");
        } catch (Exception ignored) {
        }
    }
}
