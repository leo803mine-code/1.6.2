package dev.flr.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;

/** Процедурные модели из кубиков (координаты в пикселях 1/16, y вверх, перед = -z): шапки и питомцы с анимацией. */
final class Pets {
    private static final float U = 1f / 16f;
    private static PoseStack ps;
    private static VertexConsumer vc;
    private static int light;
    private static final int PINK = 0xFFFF5FA8, BLACK = 0xFF16161C;

    private static float lookYaw, lookPitch;

    private Pets() {}

    private static float blink(float t) {
        return (t + 17f) % 95f < 4f ? 0.15f : 1f;
    }

    /** Поворот головы: смотрит туда же, куда игрок, плюс сам иногда оглядывается. */
    private static float headYaw(float t) {
        float scan = Mth.sin(t * 0.031f) * 18f * (0.5f + 0.5f * Mth.sin(t * 0.0113f));
        return Mth.clamp(-lookYaw, -45f, 45f) * 0.8f + scan;
    }

    private static float headPitch(float t) {
        return Mth.clamp(-lookPitch, -25f, 25f) * 0.6f + Mth.sin(t * 0.06f) * 2f;
    }

    private static float earFlick(float t) {
        return Mth.sin(t * 0.017f) > 0.85f ? Mth.sin(t * 0.9f) * 10f : 0f;
    }

    /** Сердечко над головой раз в ~18 секунд. */
    private static void heart(float t, float y) {
        float q = (t % 360f) / 360f / 0.22f;
        if (q > 1f) return;
        float s = Mth.sin(q * Mth.PI);
        if (s < 0.05f) return;
        ps.pushPose();
        ps.translate(0, (y + q * 8f) * U, 0);
        ps.scale(s, s, s);
        int c = 0xFFFF4F7B;
        box(-2, 3, -0.5f, -0.5f, 4, 0.5f, c); box(0.5f, 3, -0.5f, 2, 4, 0.5f, c);
        box(-2.5f, 2, -0.5f, 2.5f, 3, 0.5f, c);
        box(-1.5f, 1, -0.5f, 1.5f, 2, 0.5f, c);
        box(-0.5f, 0, -0.5f, 0.5f, 1, 0.5f, c);
        ps.popPose();
    }

    static void begin(PoseStack p, VertexConsumer v, int l) {
        ps = p; vc = v; light = l;
    }

    private static int shade(int c, float k) {
        return 0xFF000000 | (int) ((c >> 16 & 255) * k) << 16 | (int) ((c >> 8 & 255) * k) << 8 | (int) ((c & 255) * k);
    }

    private static void face(PoseStack.Pose pp, int c, float k, float nx, float ny, float nz, float[] v) {
        int col = shade(c, k);
        for (int i = 0; i < 4; i++) {
            vc.addVertex(pp.pose(), v[i * 3], v[i * 3 + 1], v[i * 3 + 2]).setColor(col).setUv(0f, 0f)
                    .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pp, nx, ny, nz);
        }
    }

    static void box(float x0, float y0, float z0, float x1, float y1, float z1, int c) {
        x0 *= U; y0 *= U; z0 *= U; x1 *= U; y1 *= U; z1 *= U;
        PoseStack.Pose p = ps.last();
        face(p, c, 1.0f, 0, 1, 0, new float[]{x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1});
        face(p, c, 0.5f, 0, -1, 0, new float[]{x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1});
        face(p, c, 0.8f, 0, 0, -1, new float[]{x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0});
        face(p, c, 0.8f, 0, 0, 1, new float[]{x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1});
        face(p, c, 0.65f, -1, 0, 0, new float[]{x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0});
        face(p, c, 0.65f, 1, 0, 0, new float[]{x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0});
    }

    private static void part(float px, float py, float pz, float rx, float ry, float rz, Runnable r) {
        ps.pushPose();
        ps.translate(px * U, py * U, pz * U);
        if (ry != 0) ps.mulPose(Axis.YP.rotationDegrees(ry));
        if (rx != 0) ps.mulPose(Axis.XP.rotationDegrees(rx));
        if (rz != 0) ps.mulPose(Axis.ZP.rotationDegrees(rz));
        r.run();
        ps.popPose();
    }

    // ---------------- шапка (в пространстве головы, верх головы y = 8) ----------------
    static void hat(int type, float t) {
        final int RED = 0xFFD92B3A, WHITE = 0xFFF6F6FA;
        ps.pushPose();
        ps.scale(1, -1, 1);
        box(-4.8f, 8, -4.8f, 4.8f, 10.4f, 4.8f, WHITE);
        float[] w = {4.2f, 3.5f, 2.7f, 1.9f}, dz = {0, 0.8f, 2.2f, 4.0f};
        for (int i = 0; i < 4; i++) {
            float yb = 10.4f + 2.5f * i;
            box(-w[i], yb, -w[i] + dz[i], w[i], yb + 2.5f, w[i] + dz[i], RED);
        }
        float sw = Mth.sin(t * 0.1f) * 1.2f;
        box(-1.6f + sw, 17.7f, 4.4f, 1.6f + sw, 20.9f, 7.6f, WHITE);
        ps.popPose();
    }

    // ---------------- питомцы (начало координат — у ног, y вверх) ----------------
    static void pet(int type, float t, float ph, float walk, float netYaw, float pitch) {
        lookYaw = netYaw;
        lookPitch = pitch;
        switch (type) {
            case 1 -> rabbit(t, ph, walk);
            case 2 -> feline(t, ph, walk, false);
            case 3 -> feline(t, ph, walk, true);
            case 4 -> penguin(t, ph, walk);
            case 5 -> door(t);
            default -> { }
        }
    }

    private static void rabbit(float t, float ph, float walk) {
        final int G = 0xFF8F94A6, G2 = 0xFF7C8196, GL = 0xFF9CA2B6, W = 0xFFEDEDF3;
        float hop = walk > 0.05f ? Math.abs(Mth.sin(ph * 0.9f)) * 2.5f * Math.min(1f, walk * 2f) : 0f;
        float br = Mth.sin(t * 0.08f) * 0.25f;
        final float hy = headYaw(t), hp = headPitch(t), k = blink(t);
        final float sw = Mth.sin(t * 0.07f) * 4f + earFlick(t), nw = 0.5f + Mth.sin(t * 0.7f) * 0.15f;
        ps.pushPose();
        ps.translate(0, hop * U, 0);
        box(-3, 2, -3, 3, 7 + br, 4, G);
        box(-3.7f, 1, 1, -2.3f, 5, 4.6f, G); box(2.3f, 1, 1, 3.7f, 5, 4.6f, G);
        part(0, 6, -2.5f, hp, hy, 0, () -> {
            box(-2.8f, 0, -4, 2.8f, 5, 1, GL);
            box(-3.2f, 0.5f, -3.5f, 3.2f, 2.8f, 0.5f, GL);
            box(-2.5f, 3 - k, -4.05f, -0.7f, 3 + k, -4f, 0xFFB8B066); box(0.7f, 3 - k, -4.05f, 2.5f, 3 + k, -4f, 0xFFB8B066);
            box(-2.1f, 3.05f - 0.75f * k, -4.1f, -1.1f, 3.05f + 0.75f * k, -4.05f, 0xFF0E0E14);
            box(1.1f, 3.05f - 0.75f * k, -4.1f, 2.1f, 3.05f + 0.75f * k, -4.05f, 0xFF0E0E14);
            if (k > 0.5f) {
                box(-1.8f, 3.3f, -4.12f, -1.5f, 3.6f, -4.1f, 0xFFFFFFFF); box(1.5f, 3.3f, -4.12f, 1.8f, 3.6f, -4.1f, 0xFFFFFFFF);
            }
            box(-nw, 0.8f, -4.15f, nw, 1.6f, -4.05f, 0xFFD79A8C);
            part(-2.7f, 4.6f, -1.5f, 0, 0, -22f + sw, () -> box(-1.4f, -5.8f, -1.2f, 0.2f, 0, 1.2f, G));
            part(2.7f, 4.6f, -1.5f, 0, 0, 22f - sw, () -> box(-0.2f, -5.8f, -1.2f, 1.4f, 0, 1.2f, G));
        });
        box(-2.5f, 0, -3, -0.8f, 2.2f, -1.2f, G); box(0.8f, 0, -3, 2.5f, 2.2f, -1.2f, G);
        box(-2.5f, 0, -3.3f, -0.8f, 0.9f, -1.2f, W); box(0.8f, 0, -3.3f, 2.5f, 0.9f, -1.2f, W);
        box(-3.7f, 0, 0.5f, -2.3f, 1.2f, 4.8f, G2); box(2.3f, 0, 0.5f, 3.7f, 1.2f, 4.8f, G2);
        float tw = Mth.sin(t * 0.25f) * 0.5f;
        box(-1.2f + tw, 3, 4, 1.2f + tw, 5.4f, 6.2f, W);
        heart(t, 13);
        ps.popPose();
    }

    private static void feline(float t, float ph, float walk, boolean jag) {
        final int B = jag ? 0xFFD8A23A : 0xFFE29A4B, BL = jag ? 0xFFF1DDA8 : 0xFFF6EFE6, D = jag ? 0xFF1B1410 : 0xFFB5651F;
        float s = jag ? 1.3f : 1f, swing = Math.min(1f, walk * 2f) * 38f;
        final float hy = headYaw(t), hp = headPitch(t), k = blink(t), ear = earFlick(t);
        ps.pushPose();
        ps.scale(s, s, s);
        box(-2.5f, 3.5f, -4, 2.5f, 8, 4, B);
        box(-2, 3.5f, -3.5f, 2, 4.2f, 3.5f, BL);
        float[][] legs = {{-1.7f, -3f, 0}, {1.7f, -3f, Mth.PI}, {-1.7f, 2.5f, Mth.PI}, {1.7f, 2.5f, 0}};
        for (float[] l : legs) {
            float a = Mth.sin(ph * 0.7f + l[2]) * swing;
            part(l[0], 3.6f, l[1], a, 0, 0, () -> {
                box(-0.9f, -3.6f, -0.9f, 0.9f, 0, 0.9f, B);
                box(-0.9f, -3.6f, -1.2f, 0.9f, -2.6f, 0.9f, BL);
            });
        }
        if (jag) {
            float[][] sp = {{-1.5f, -2}, {1.2f, -1}, {-0.8f, 0.5f}, {1.5f, 1.8f}, {-1.6f, 2.5f}, {0.2f, -3}, {0.4f, 3.2f}};
            for (float[] q : sp) box(q[0] - 0.5f, 8, q[1] - 0.5f, q[0] + 0.5f, 8.15f, q[1] + 0.5f, D);
            for (float z : new float[]{-2.5f, -0.5f, 1.5f, 3f}) {
                box(2.5f, 5.4f, z - 0.5f, 2.65f, 6.4f, z + 0.5f, D);
                box(-2.65f, 6.0f, z - 0.3f, -2.5f, 7.0f, z + 0.7f, D);
            }
        } else {
            for (float z : new float[]{-2.5f, -0.5f, 1.5f, 3f}) box(-2.5f, 8, z, 2.5f, 8.15f, z + 0.8f, D);
        }
        part(0, 7, -3.6f, hp, hy, 0, () -> {
            box(-3, 0, -4.4f, 3, 5, 0.4f, B);
            box(-1.6f, 0.4f, -5f, 1.6f, 2.6f, -4.4f, BL);
            part(-2f, 5, -1.8f, 0, 0, ear, () -> box(-0.8f, 0, -0.6f, 0.8f, 2.2f, 0.6f, B));
            part(2f, 5, -1.8f, 0, 0, -ear, () -> box(-0.8f, 0, -0.6f, 0.8f, 2.2f, 0.6f, B));
            box(-2.3f, 3.2f - 0.6f * k, -4.45f, -0.9f, 3.2f + 0.6f * k, -4.4f, 0xFF9BE070);
            box(0.9f, 3.2f - 0.6f * k, -4.45f, 2.3f, 3.2f + 0.6f * k, -4.4f, 0xFF9BE070);
            box(-1.8f, 3.2f - 0.5f * k, -4.5f, -1.3f, 3.2f + 0.5f * k, -4.45f, 0xFF101014);
            box(1.3f, 3.2f - 0.5f * k, -4.5f, 1.8f, 3.2f + 0.5f * k, -4.45f, 0xFF101014);
            box(-0.5f, 1.6f, -5.05f, 0.5f, 2.2f, -4.95f, 0xFFD99AA0);
            if (jag) { box(-1.5f, 4.2f, -4.45f, -0.9f, 4.8f, -4.4f, D); box(0.9f, 4.2f, -4.45f, 1.5f, 4.8f, -4.4f, D); }
        });
        float wag = Mth.sin(t * (0.1f + walk * 0.12f)) * 18f;
        part(0, 7, 4, -30f, wag, 0, () -> {
            box(-0.7f, -0.7f, 0, 0.7f, 0.7f, 3.5f, B);
            part(0, 0, 3.5f, -25f, wag * 0.8f, 0, () -> {
                box(-0.7f, -0.7f, 0, 0.7f, 0.7f, 3.5f, B);
                box(-0.75f, -0.75f, 2.6f, 0.75f, 0.75f, 3.5f, D);
            });
        });
        heart(t, 15);
        ps.popPose();
    }

    private static void penguin(float t, float ph, float walk) {
        final int GR = 0xFF7D828E, DK = 0xFF474B56, BE = 0xFFD8DAE2, OR = 0xFFE9953A;
        float w = Math.min(1f, walk * 2f);
        float sway = Mth.sin(ph * 0.8f) * 10f * w + Mth.sin(t * 0.04f) * 1.5f;
        float flap = Mth.sin(t * 0.1f) * 3f + w * Mth.sin(ph * 0.8f + 1.5f) * 25f + (Mth.sin(t * 0.021f) > 0.9f ? Mth.sin(t * 0.8f) * 25f : 0f);
        final float hy = headYaw(t) * 1.2f, hp = headPitch(t) + Mth.sin(t * 0.05f) * 1.2f, k = blink(t);
        float foot = Mth.sin(ph * 0.8f) * 35f * w;
        part(0, 0, 0, 0, 0, sway, () -> {
            box(-3.6f, 1, -3, 3.6f, 8.5f, 3, GR);
            box(-2.6f, 1.4f, -3.05f, 2.6f, 8, -3, BE);
            box(-1.5f, 1, 3, 1.5f, 3, 4.5f, DK);
            part(0, 8.5f, 0, hp, hy, 0, () -> {
                box(-3, 0, -2.7f, 3, 4.5f, 2.7f, DK);
                box(-2.2f, 3 - 0.7f * k, -2.75f, -0.9f, 3 + 0.7f * k, -2.7f, 0xFFF2F2F6);
                box(0.9f, 3 - 0.7f * k, -2.75f, 2.2f, 3 + 0.7f * k, -2.7f, 0xFFF2F2F6);
                box(-1.7f, 2.9f - 0.45f * k, -2.8f, -1.2f, 2.9f + 0.45f * k, -2.75f, 0xFF0E0E14);
                box(1.2f, 2.9f - 0.45f * k, -2.8f, 1.7f, 2.9f + 0.45f * k, -2.75f, 0xFF0E0E14);
                box(-1, 1.1f, -4.6f, 1, 2.3f, -2.7f, OR);
            });
            part(-3.8f, 7.5f, 0, 0, 0, -(12f + flap), () -> box(-1, -5, -1.4f, 0, 0, 1.4f, DK));
            part(3.8f, 7.5f, 0, 0, 0, 12f + flap, () -> box(0, -5, -1.4f, 1, 0, 1.4f, DK));
            part(-1.6f, 1, 0.5f, foot, 0, 0, () -> box(-1, -1, -2.5f, 1, 0.2f, 0.5f, OR));
            part(1.6f, 1, 0.5f, -foot, 0, 0, () -> box(-1, -1, -2.5f, 1, 0.2f, 0.5f, OR));
        });
        heart(t, 16);
    }

    private static void door(float t) {
        final int WH = 0xFFF4F4F8, WS = 0xFFDADCE6, FR = 0xFFC9CBD6, GD = 0xFFE3C15A, CR = 0xFF55586A;
        float bob = Mth.sin(t * 0.05f) * 0.6f, swing = Mth.sin(t * 0.035f) * 12f - 6f;
        ps.pushPose();
        ps.translate(0, bob * U, 0);
        box(-6, 0, -1, -5, 21, 1, FR);
        box(5, 0, -1, 6, 13, 1, FR); box(5, 16.5f, -1, 6, 21, 1, FR);
        box(-6, 20, -1, 2, 21, 1, FR);
        part(-5, 0, 0, 0, swing, 0, () -> {
            box(0, 0, -0.7f, 10, 15, 0.7f, WH);
            box(0, 15, -0.7f, 6.5f, 20, 0.7f, WH);
            box(6.5f, 15, -0.7f, 8.5f, 17.5f, 0.7f, WH);
            box(1.2f, 1.5f, -0.8f, 8.8f, 8.5f, -0.7f, WS); box(1.2f, 10.5f, -0.8f, 5.8f, 18.5f, -0.7f, WS);
            box(8.1f, 9.2f, -1.5f, 9.4f, 10.6f, -0.7f, GD);
            box(5.8f, 10.5f, -0.85f, 6.2f, 13f, -0.8f, CR); box(6.2f, 13f, -0.85f, 7.4f, 13.4f, -0.8f, CR);
            box(2.4f, 3f, -0.85f, 2.8f, 6.5f, -0.8f, CR); box(2.8f, 6.5f, -0.85f, 4f, 6.9f, -0.8f, CR);
        });
        box(2, 0, -3, 3.4f, 0.6f, -2.2f, WH); box(-2, 0, 2, -0.8f, 0.5f, 3.2f, WS); box(6, 0, -2, 7, 0.8f, -1.2f, WH);
        ps.popPose();
    }
}
