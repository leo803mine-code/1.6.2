package dev.flr.visuals;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Экран переключателя аккаунтов: список ников, добавление, удаление, возврат к оригинальному аккаунту. */
public class AccountScreen extends Screen {
    private static final int ROWS = 5, ROW_H = 22, PW = 280;

    private final Screen parent;
    private EditBox input;
    private String nick = "";
    private int offset;
    private String status = "";
    private int statusColor = 0x9094B4;
    private int px, py, ph;

    public AccountScreen(Screen parent) {
        super(Component.literal("FLR Accounts"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        ph = 62 + ROWS * ROW_H + 70;
        px = (width - PW) / 2;
        py = Math.max(4, (height - ph) / 2);

        input = new EditBox(font, px + 10, py + 56, PW - 100, 18, Component.literal(Tr.tr("Nickname")));
        input.setMaxLength(16);
        input.setValue(nick);
        input.setHint(Component.literal(Tr.tr("Nickname")));
        input.setResponder(v -> nick = v);
        addRenderableWidget(input);
        addRenderableWidget(Button.builder(Component.literal(Tr.tr("Add & use")), b -> addAndUse())
                .bounds(px + PW - 84, py + 55, 74, 20).build());

        List<String> names = AccountManager.names();
        offset = Math.max(0, Math.min(offset, Math.max(0, names.size() - ROWS)));
        int y = py + 84;
        for (int i = 0; i < ROWS && offset + i < names.size(); i++) {
            String n = names.get(offset + i);
            addRenderableWidget(Button.builder(Component.literal(Tr.tr("Use")), b -> use(n))
                    .bounds(px + PW - 80, y + i * ROW_H, 44, 20).build());
            addRenderableWidget(Button.builder(Component.literal("X"), b -> remove(n))
                    .bounds(px + PW - 32, y + i * ROW_H, 22, 20).build());
        }

        int by = py + ph - 28;
        addRenderableWidget(Button.builder(Component.literal(Tr.tr("Original account")), b -> restore())
                .bounds(px + 10, by, 130, 20).build());
        addRenderableWidget(Button.builder(Component.literal(Tr.tr("Back")), b -> onClose())
                .bounds(px + PW - 90, by, 80, 20).build());
    }

    private void addAndUse() {
        String n = nick.trim();
        if (!AccountManager.add(n)) {
            status = Tr.tr("Nickname: 3-16 letters, digits or _");
            statusColor = 0xFF7070;
            return;
        }
        nick = "";
        use(n);
    }

    private void use(String n) {
        AccountManager.switchTo(n);
        status = Tr.fmt("Now playing as %s (applies to the next server connection)", n);
        statusColor = 0x6FE09A;
        rebuildWidgets();
    }

    private void remove(String n) {
        AccountManager.remove(n);
        rebuildWidgets();
    }

    private void restore() {
        AccountManager.restoreOriginal();
        status = Tr.fmt("Original account restored: %s", AccountManager.current());
        statusColor = 0x6FE09A;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        int max = Math.max(0, AccountManager.names().size() - ROWS);
        int next = Math.max(0, Math.min(max, offset - (int) Math.signum(sy)));
        if (next != offset) {
            offset = next;
            rebuildWidgets();
        }
        return true;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        super.render(g, mx, my, pt);
    }

    /** Фон и панель рисуются здесь: Screen.render вызывает этот метод раньше виджетов. */
    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
        g.fill(0, 0, width, height, 0xA004050A);
        int accent = Config.color() & 0xFFFFFF;
        CosmeticsScreen.rrect(g, px - 1, py - 1, PW + 2, ph + 2, 11, 0x57000000 | accent);
        CosmeticsScreen.rrect(g, px, py, PW, ph, 10, 0xF811121B);

        g.drawString(font, Tr.tr("Account switcher"), px + 12, py + 12, 0xFF000000 | accent, false);
        String cur = Tr.fmt("Current: %s", AccountManager.current());
        g.drawString(font, cur, px + 12, py + 28, 0xFFFFFFFF, false);
        g.drawString(font, AccountManager.isOriginalActive() ? Tr.tr("Original account") : Tr.tr("Offline account"),
                px + 12, py + 40, 0xFF6C7090, false);

        List<String> names = AccountManager.names();
        int y = py + 84;
        for (int i = 0; i < ROWS && offset + i < names.size(); i++) {
            String n = names.get(offset + i);
            boolean active = n.equals(AccountManager.current());
            CosmeticsScreen.rrect(g, px + 10, y + i * ROW_H, PW - 96, 20, 7, active ? 0x59000000 | accent : 0xFF181A27);
            g.drawString(font, n, px + 18, y + i * ROW_H + 6, active ? 0xFFFFFFFF : 0xFFB4B8D2, false);
        }
        if (names.isEmpty()) g.drawString(font, Tr.tr("No saved accounts yet"), px + 12, y + 6, 0xFF6C7090, false);

        int sy = py + ph - 50;
        if (!status.isEmpty()) {
            g.drawString(font, font.plainSubstrByWidth(status, PW - 20), px + 12, sy, 0xFF000000 | statusColor, false);
        }
        g.drawString(font, font.plainSubstrByWidth(Tr.tr("Offline nicknames only. Premium servers will reject them."), PW - 20),
                px + 12, sy + 11, 0xFF5E6280, false);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }
}
