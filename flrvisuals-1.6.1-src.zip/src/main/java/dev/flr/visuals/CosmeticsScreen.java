package dev.flr.visuals;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class CosmeticsScreen extends Screen {
    private static final int SIDE = 112, TAB_H = 22, TAB_STEP = 24;
    private static final String VERSION = "v1.6.1";
    private static final String[] TABS = {"Cosmetics", "Effects", "Atmosphere", "Colors", "Utility", "Performance", "Settings"};

    private final List<List<Row>> pages = new ArrayList<>();
    private int tab;
    private Row openRow;
    private List<Row> openSub;
    private float tabY = -1, openAnim, pageAnim = 1f, scroll, scrollTarget;
    private long last;
    private Row dragging;
    private int sel;
    private boolean padMode;
    private int W, H, px, py, cx, cw, rtop, rbot, mouseX, mouseY;
    private final int[] ys = new int[64], hs = new int[64];

    public CosmeticsScreen() {
        super(Component.literal("FLR VISUALS"));
    }

    // ---------- строки ----------
    private static final class Row {
        final String label;
        final int type; // 0 toggle, 1 choice, 2 slider, 3 button
        String desc;
        boolean warn, rainbow;
        BooleanSupplier bget; Consumer<Boolean> bset;
        String[] names; IntSupplier iget; IntConsumer iset;
        DoubleSupplier dget; DoubleConsumer dset; double min, max; boolean isInt;
        Runnable action;
        String btn = "Reset";
        java.util.function.Supplier<String> btnSup;
        List<Row> sub;
        String subTitle;
        float anim, hov;

        Row(String label, int type) { this.label = label; this.type = type; }

        int height() { return desc != null ? 38 : 27; }

        Row btn(String b) { this.btn = b; return this; }
        Row desc(String d) { this.desc = d; return this; }
        Row warn(String d) { this.desc = d; this.warn = true; return this; }
        Row rainbow() { this.rainbow = true; return this; }
        Row sub(String title, Row... rows) { this.subTitle = title; this.sub = List.of(rows); return this; }
    }

    private static Row toggle(String l, BooleanSupplier g, Consumer<Boolean> s) {
        Row r = new Row(l, 0); r.bget = g; r.bset = s; r.anim = g.getAsBoolean() ? 1f : 0f; return r;
    }
    private static Row choice(String l, String[] n, IntSupplier g, IntConsumer s) {
        Row r = new Row(l, 1); r.names = n; r.iget = g; r.iset = s; return r;
    }
    private static Row slider(String l, double min, double max, boolean isInt, DoubleSupplier g, DoubleConsumer s) {
        Row r = new Row(l, 2); r.min = min; r.max = max; r.isInt = isInt; r.dget = g; r.dset = s; return r;
    }
    private static Row button(String l, Runnable a) {
        Row r = new Row(l, 3); r.action = a; return r;
    }
    private static KeyMapping capturing;

    private static Row key(String l, KeyMapping km) {
        Row r = new Row(l, 3);
        r.action = () -> capturing = km;
        r.btnSup = () -> capturing == km ? Tr.tr("Press a key...") : km.getTranslatedKeyMessage().getString();
        return r;
    }

    private static void bindCaptured(com.mojang.blaze3d.platform.InputConstants.Key k) {
        capturing.setKey(k);
        KeyMapping.resetMapping();
        Minecraft.getInstance().options.save();
        capturing = null;
    }

    private static Row msgChoice() {
        return choice("Messages", Config.MSG_NAMES, () -> Config.msgMode, v -> Config.msgMode = v);
    }

    @Override
    protected void init() {
        if (!pages.isEmpty()) return;

        // 0 Cosmetics
        pages.add(List.of(
                toggle("Wings", () -> Config.wings, v -> Config.wings = v).sub("Wing settings",
                        choice("Wing type", Config.WING_NAMES, () -> Config.wingStyle, v -> Config.wingStyle = v),
                        slider("Size", 0.5, 1.6, false, () -> Config.wingSize, v -> Config.wingSize = v),
                        slider("Opacity", 0.2, 1.0, false, () -> Config.wingAlpha, v -> Config.wingAlpha = v),
                        slider("Angle", -25, 35, false, () -> Config.wingAngle, v -> Config.wingAngle = v),
                        slider("Gap between wings", 0, 0.15, false, () -> Config.wingGap, v -> Config.wingGap = v),
                        slider("Height", -0.2, 0.2, false, () -> Config.wingHeight, v -> Config.wingHeight = v),
                        slider("Distance from back", -0.05, 0.2, false, () -> Config.wingDepth, v -> Config.wingDepth = v),
                        slider("Flap amount", 0, 2, false, () -> Config.wingFlap, v -> Config.wingFlap = v),
                        slider("Flap speed", 0.2, 3.0, false, () -> Config.speed, v -> Config.speed = v),
                        choice("Colour mode", Config.WING_COLOR_NAMES, () -> Config.wingColorMode, v -> Config.wingColorMode = v),
                        slider("Hue", 0, 1, false, () -> Config.wingHue, v -> Config.wingHue = v).rainbow(),
                        slider("Saturation", 0, 1, false, () -> Config.wingSat, v -> Config.wingSat = v),
                        slider("Brightness", 0.2, 1, false, () -> Config.wingBri, v -> Config.wingBri = v)),
                toggle("Halo", () -> Config.halo, v -> Config.halo = v).sub("Halo settings",
                        slider("Size", 0.6, 2.0, false, () -> Config.haloSize, v -> Config.haloSize = v),
                        slider("Height", -0.1, 0.3, false, () -> Config.haloHeight, v -> Config.haloHeight = v),
                        choice("Colour mode", Config.COLOR_NAMES, () -> Config.haloColorMode, v -> Config.haloColorMode = v),
                        slider("Hue", 0, 1, false, () -> Config.haloHue, v -> Config.haloHue = v).rainbow(),
                        slider("Saturation", 0, 1, false, () -> Config.haloSat, v -> Config.haloSat = v),
                        slider("Brightness", 0.2, 1, false, () -> Config.haloBri, v -> Config.haloBri = v)),
                toggle("Cape", () -> Config.cape, v -> Config.cape = v).sub("Cape settings",
                        slider("Length", 0.5, 1.6, false, () -> Config.capeLength, v -> Config.capeLength = v),
                        slider("Width", 0.5, 1.6, false, () -> Config.capeWidth, v -> Config.capeWidth = v),
                        slider("Sway", 0, 2, false, () -> Config.capeSway, v -> Config.capeSway = v),
                        choice("Colour mode", Config.CAPE_COLOR_NAMES, () -> Config.capeColorMode, v -> Config.capeColorMode = v),
                        slider("Hue (top)", 0, 1, false, () -> Config.capeHue, v -> Config.capeHue = v).rainbow(),
                        slider("Hue (bottom)", 0, 1, false, () -> Config.capeHue2, v -> Config.capeHue2 = v).rainbow(),
                        slider("Saturation", 0, 1, false, () -> Config.capeSat, v -> Config.capeSat = v),
                        slider("Brightness", 0.2, 1, false, () -> Config.capeBri, v -> Config.capeBri = v)),
                choice("Hat", Config.HAT_NAMES, () -> Config.hat, v -> Config.hat = v),
                choice("Pet", Config.PET_NAMES, () -> Config.pet, v -> Config.pet = v),
                slider("Pet size", 0.5, 1.5, false, () -> Config.petSize, v -> Config.petSize = v),
                toggle("Show on other players", () -> Config.others, v -> Config.others = v),
                toggle("Show on invisible players", () -> Config.showInvisible, v -> Config.showInvisible = v)
                        .warn("At your own risk: may break server rules")));

        // 1 Effects
        pages.add(List.of(
                toggle("Aura", () -> Config.aura, v -> Config.aura = v),
                toggle("Trail", () -> Config.trail, v -> Config.trail = v),
                toggle("Hit sparks", () -> Config.hitSparks, v -> Config.hitSparks = v),
                toggle("Ambient fireflies", () -> Config.ambient, v -> Config.ambient = v),
                choice("Particle type", Config.PARTICLE_NAMES, () -> Config.particleType, v -> Config.particleType = v),
                slider("Effect scale", 0.5, 2.0, false, () -> Config.scale, v -> Config.scale = v)));

        // 2 Atmosphere
        pages.add(List.of(
                slider("Fog tint", 0, 1, false, () -> Config.fogTint, v -> Config.fogTint = v).desc("Tints the fog with the theme colour"),
                slider("Fog density", 0, 1, false, () -> Config.fogDensity, v -> Config.fogDensity = v).desc("Closer, thicker fog"),
                toggle("Colour sky", () -> Config.sky, v -> Config.sky = v).sub("Sky settings",
                        choice("Colour mode", Config.SKY_NAMES, () -> Config.skyMode, v -> Config.skyMode = v),
                        slider("Hue", 0, 1, false, () -> Config.skyHue, v -> Config.skyHue = v).rainbow(),
                        slider("Sky strength", 0.1, 1, false, () -> Config.skyAlpha, v -> Config.skyAlpha = v))));

        // 3 Colors
        pages.add(List.of(
                choice("Theme", Config.THEME_NAMES, () -> Config.theme, v -> Config.theme = v).desc("Used by wings, halo, cape, fog, HUD"),
                slider("Custom hue", 0, 1, false, () -> Config.hue, v -> Config.hue = v).rainbow(),
                slider("Custom saturation", 0, 1, false, () -> Config.themeSat, v -> Config.themeSat = v)));

        // 4 Utility
        pages.add(List.of(
                toggle("Auto Swap", () -> Config.autoSwap, v -> Config.autoSwap = v)
                        .desc("Totem to offhand when falling").sub("Auto Swap settings",
                                key("Keybind", FlrKeys.AUTOSWAP),
                                slider("Fall height (blocks)", 5, 20, true, () -> Config.swapHeight, v -> Config.swapHeight = (int) Math.round(v)),
                                msgChoice()),
                toggle("Armor Alert", () -> Config.armorAlert, v -> Config.armorAlert = v)
                        .desc("Warns when armor is about to break").sub("Armor Alert settings",
                                slider("Warn below (%)", 5, 50, true, () -> Config.armorPercent, v -> Config.armorPercent = (int) Math.round(v)),
                                msgChoice()),
                msgChoice().desc("Where function messages are shown")));

        // 5 Performance
        pages.add(List.of(
                toggle("Auto performance", () -> Config.autoPerf, v -> Config.autoPerf = v).desc("Lowers detail when FPS is low"),
                toggle("FPS counter", () -> Config.hud, v -> Config.hud = v),
                slider("Particle budget", 0, 100, true, () -> Config.particleBudget, v -> Config.particleBudget = (int) Math.round(v)),
                slider("Max distance", 8, 96, true, () -> Config.maxDistance, v -> Config.maxDistance = (int) Math.round(v)),
                slider("Max players", 1, 32, true, () -> Config.maxPlayers, v -> Config.maxPlayers = (int) Math.round(v)),
                slider("Detail distance", 8, 64, true, () -> Config.lodDistance, v -> Config.lodDistance = (int) Math.round(v))
                        .desc("Simple wings farther than this")));

        // 6 Settings
        pages.add(List.of(
                toggle("FLR Visuals enabled", () -> Config.master, v -> Config.master = v),
                choice("Language", Config.LANG_NAMES, () -> Config.lang, v -> Config.lang = v),
                button("Account switcher", () -> Minecraft.getInstance().setScreen(new AccountScreen(this)))
                        .btn("Open").desc("Switch offline nickname in game"),
                toggle("Custom menu style", () -> Config.menuStyle, v -> Config.menuStyle = v)
                        .desc("Black PS-style menu and loading"),
                key("Open menu key", FlrKeys.MENU),
                toggle("Gamepad support", () -> Config.gamepad, v -> Config.gamepad = v)
                        .desc("D-pad, A/B/X buttons, LB/RB tabs"),
                button("Reset to defaults", Config::reset)));
    }

    // ---------- утилиты рисования ----------
    private static float k(float dt, float rate) { return 1f - (float) Math.exp(-rate * dt); }

    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }

    private static float ease(float t) { t = clamp01(t); return t * t * (3f - 2f * t); }

    private static int rgba(int rgb, float a) {
        int a8 = Math.max(4, Math.min(255, (int) (a * 255f)));
        return a8 << 24 | (rgb & 0xFFFFFF);
    }

    private static int mix(int a, int b, float t) {
        int r = (int) ((a >> 16 & 255) * (1 - t) + (b >> 16 & 255) * t);
        int g = (int) ((a >> 8 & 255) * (1 - t) + (b >> 8 & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return r << 16 | g << 8 | bl;
    }

    /** Скруглённый прямоугольник со сглаженными краями (частичная прозрачность на крайнем пикселе). */
    static void rrect(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { g.fill(x, y, x + w, y + h, c); return; }
        g.fill(x, y + r, x + w, y + h - r, c);
        int a0 = c >>> 24;
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            double off = r - Math.sqrt(r * r - d * d);
            int in = (int) Math.ceil(off);
            g.fill(x + in, y + i, x + w - in, y + i + 1, c);
            g.fill(x + in, y + h - i - 1, x + w - in, y + h - i, c);
            if (in > 0) {
                int a = (int) (a0 * (in - off));
                if (a > 3) {
                    int ca = a << 24 | (c & 0xFFFFFF);
                    g.fill(x + in - 1, y + i, x + in, y + i + 1, ca);
                    g.fill(x + w - in, y + i, x + w - in + 1, y + i + 1, ca);
                    g.fill(x + in - 1, y + h - i - 1, x + in, y + h - i, ca);
                    g.fill(x + w - in, y + h - i - 1, x + w - in + 1, y + h - i, ca);
                }
            }
        }
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private List<Row> cur() { return openSub != null ? openSub : pages.get(tab); }

    private int contentHeight() {
        int s = 0;
        for (Row r : cur()) s += r.height();
        return s;
    }

    private void resetPage() { scroll = 0; scrollTarget = 0; pageAnim = 0f; sel = 0; }

    private void openSettings(Row r) {
        if (r.sub == null) return;
        openRow = r; openSub = r.sub; resetPage();
    }

    private void closeSettings() {
        openRow = null; openSub = null; resetPage();
    }

    // ---------- рендер ----------
    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        mouseX = mx; mouseY = my;
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        openAnim += (1f - openAnim) * k(dt, 11f);
        pageAnim = Math.min(1f, pageAnim + dt * 3.2f);
        float e = ease(openAnim);
        int accent = Config.color() & 0xFFFFFF;

        W = Math.min(460, width - 8);
        H = Math.min(290, height - 8);
        px = (width - W) / 2;
        py = (height - H) / 2 + (int) ((1f - e) * 14);
        cx = px + SIDE + 10;
        cw = W - SIDE - 20;
        rtop = py + 38;
        rbot = py + H - 20;

        g.fill(0, 0, width, height, rgba(0x04050A, 0.62f * e));

        // панель: мягкое свечение, фон, боковая колонка
        rrect(g, px - 2, py - 2, W + 4, H + 4, 12, rgba(accent, 0.12f * e));
        rrect(g, px - 1, py - 1, W + 2, H + 2, 11, rgba(accent, 0.34f * e));
        rrect(g, px, py, W, H, 10, rgba(0x11121B, 0.97f * e));
        g.fillGradient(px + 4, py + 2, px + W - 4, py + 34, rgba(accent, 0.10f * e), rgba(accent, 0.0f));
        rrect(g, px + 6, py + 6, SIDE - 6, H - 12, 8, rgba(0x171926, e));

        g.drawString(font, "FLR VISUALS", px + 16, py + 15, rgba(accent, e), false);
        g.drawString(font, VERSION, px + 16, py + 26, rgba(0x6C7090, e), false);

        // вкладки + плавный индикатор
        float target = py + 42 + tab * TAB_STEP;
        tabY = tabY < 0 ? target : tabY + (target - tabY) * k(dt, 16f);
        rrect(g, px + 11, (int) tabY, SIDE - 16, TAB_H, 7, rgba(accent, 0.20f * e));
        rrect(g, px + 11, (int) tabY + 4, 2, TAB_H - 8, 1, rgba(accent, e));
        for (int i = 0; i < TABS.length; i++) {
            int ty = py + 42 + i * TAB_STEP;
            boolean h = in(mx, my, px + 11, ty, SIDE - 16, TAB_H);
            int col = i == tab ? 0xFFFFFF : h ? 0xC4C8E0 : 0x8A8EAA;
            rrect(g, px + 19, ty + 8, 6, 6, 3, rgba(i == tab ? accent : mix(0x3A3D55, accent, h ? 0.5f : 0.0f), e));
            g.drawString(font, Tr.tr(TABS[i]), px + 31, ty + 7, rgba(col, e), false);
        }

        // статус
        int sy = py + H - 28;
        boolean on = Config.master;
        boolean sh = in(mx, my, px + 11, sy, SIDE - 16, 18);
        rrect(g, px + 11, sy, SIDE - 16, 18, 7, rgba(sh ? 0x262941 : 0x1F2133, e));
        float pulse = 0.65f + 0.35f * (float) Math.sin(now / 3.0e8);
        rrect(g, px + 18, sy + 6, 6, 6, 3, rgba(on ? 0x4CE08A : 0xE0524C, on ? pulse * e : e));
        g.drawString(font, Tr.tr(on ? "ACTIVE" : "OFF").toUpperCase(java.util.Locale.ROOT), px + 30, sy + 5, rgba(on ? 0xCFFFE3 : 0xFFCFCF, e), false);

        // заголовок страницы
        if (openSub != null) {
            boolean bh = in(mx, my, cx, py + 9, 54, 18);
            rrect(g, cx, py + 9, 54, 18, 8, rgba(mix(0x23263A, accent, bh ? 0.35f : 0.14f), e));
            g.drawString(font, "< " + Tr.tr("Back"), cx + 9, py + 14, rgba(0xFFFFFF, e), false);
            g.drawString(font, Tr.tr(openRow.subTitle), cx + 64, py + 14, rgba(accent, e), false);
        } else {
            g.drawString(font, Tr.tr(TABS[tab]), cx + 2, py + 13, rgba(0xFFFFFF, e), false);
            rrect(g, cx + 2, py + 25, 22, 2, 1, rgba(accent, e));
        }
        String hint = padMode
                ? (openSub != null ? "A: select  B: back  Left/Right: change" : "A: select  X: settings  LB/RB: tabs")
                : (openSub != null ? "Right-click or Esc: back" : "Right-click a feature: its settings");
        g.drawString(font, font.plainSubstrByWidth(Tr.tr(hint), cw), cx + 2, py + H - 14, rgba(0x5E6280, e), false);

        // ряды
        List<Row> rows = cur();
        int total = contentHeight();
        float maxScroll = Math.max(0, total - (rbot - rtop));
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        scroll += (scrollTarget - scroll) * k(dt, 16f);

        g.enableScissor(cx - 4, rtop, cx + cw + 4, rbot);
        int y = rtop - Math.round(scroll);
        for (int j = 0; j < rows.size() && j < ys.length; j++) {
            Row r = rows.get(j);
            int h = r.height() - 3;
            ys[j] = y;
            hs[j] = h;
            if (y + h < rtop || y > rbot) { y += r.height(); continue; }
            float a = ease(pageAnim * 1.7f - j * 0.09f);
            float fade = Math.min(1f, e * a);
            int yy = y + Math.round((1f - a) * 8f);
            boolean hv = (!padMode && in(mx, my, cx, yy, cw, h) && my >= rtop && my < rbot) || r == dragging || (padMode && j == sel);
            r.hov += ((hv ? 1f : 0f) - r.hov) * k(dt, 18f);
            rrect(g, cx, yy, cw, h, 7, rgba(mix(0x181A27, 0x252940, r.hov), fade));
            if (r.hov > 0.03f) rrect(g, cx + 1, yy + 5, 2, h - 10, 1, rgba(accent, r.hov * fade));
            int labelY = r.desc == null ? yy + (h - 8) / 2 : yy + 8;
            g.drawString(font, Tr.tr(r.label), cx + 10, labelY, rgba(mix(0xB4B8D2, 0xFFFFFF, r.hov), fade), false);
            if (r.desc != null) {
                int maxW = r.type == 0 ? cw - 100 : cw - 150;
                String d = font.plainSubstrByWidth(Tr.tr(r.desc), Math.max(40, maxW));
                g.drawString(font, d, cx + 10, yy + 21, rgba(r.warn ? 0xFF9B4D : 0x6F7394, fade), false);
            }
            drawControl(g, r, yy, h, accent, fade, dt, hv);
            y += r.height();
        }
        g.disableScissor();

        if (maxScroll > 0) {
            int trackH = rbot - rtop;
            int barH = Math.max(14, (int) (trackH * trackH / (float) total));
            int barY = rtop + (int) ((trackH - barH) * (scroll / maxScroll));
            rrect(g, px + W - 8, barY, 3, barH, 1, rgba(accent, 0.45f * e));
        }
    }

    private int gearX() { return cx + cw - 10 - 30 - 8 - 20; }

    private void drawControl(GuiGraphics g, Row r, int y, int h, int accent, float a, float dt, boolean hv) {
        int right = cx + cw - 10;
        int cy = y + h / 2;
        switch (r.type) {
            case 0 -> {
                r.anim += ((r.bget.getAsBoolean() ? 1f : 0f) - r.anim) * k(dt, 14f);
                float t = ease(r.anim);
                int pw = 32, ph = 16, x = right - pw, yy = cy - ph / 2;
                rrect(g, x, yy, pw, ph, ph / 2, rgba(mix(0x383B52, accent, t), a));
                int kd = ph - 4;
                int kw = kd + Math.round((float) Math.sin(Math.PI * t) * 2f);
                int kx = x + 2 + Math.round(t * (pw - 4 - kw));
                rrect(g, kx, yy + 2, kw, kd, kd / 2, rgba(mix(0xA0A4BE, 0xFFFFFF, t), a));
                if (r.sub != null) {
                    int gx = gearX(), gy = cy - 7;
                    boolean gh = in(mouseX, mouseY, gx, gy, 20, 14);
                    rrect(g, gx, gy, 20, 14, 7, rgba(mix(0x262941, accent, gh ? 0.45f : 0.16f), a));
                    g.drawString(font, ">", gx + 7, gy + 3, rgba(gh ? 0xFFFFFF : 0x9094B4, a), false);
                }
            }
            case 1 -> {
                int pw = 112, x = right - pw, ph = 16, yy = cy - ph / 2;
                rrect(g, x, yy, pw, ph, 8, rgba(mix(0x22243A, accent, hv ? 0.22f : 0.12f), a));
                String t = Tr.tr(r.names[Math.max(0, Math.min(r.names.length - 1, r.iget.getAsInt()))]);
                g.drawString(font, "<", x + 6, yy + 4, rgba(0x7E83A6, a), false);
                g.drawString(font, ">", x + pw - 12, yy + 4, rgba(0x7E83A6, a), false);
                g.drawString(font, t, x + (pw - font.width(t)) / 2, yy + 4, rgba(accent, a), false);
            }
            case 2 -> {
                int tx = sliderX(), tw = sliderW(), ty = cy - 2;
                double v = r.dget.getAsDouble();
                float f = clamp01((float) ((v - r.min) / (r.max - r.min)));
                if (r.rainbow) {
                    for (int i = 0; i < tw; i += 2)
                        g.fill(tx + i, ty, tx + Math.min(tw, i + 2), ty + 4, rgba(java.awt.Color.HSBtoRGB(i / (float) tw, 0.75f, 1f), a));
                } else {
                    rrect(g, tx, ty, tw, 4, 2, rgba(0x343750, a));
                    rrect(g, tx, ty, Math.max(4, (int) (tw * f)), 4, 2, rgba(accent, a));
                }
                int kx = tx + (int) (tw * f) - 4;
                rrect(g, kx - 1, ty - 4, 10, 12, 5, rgba(0x000000, a * 0.35f));
                rrect(g, kx, ty - 3, 8, 10, 4, rgba(0xFFFFFF, a));
                String s = r.isInt ? String.valueOf(Math.round(v)) : (r.max - r.min >= 10 ? String.format("%.1f", v) : String.format("%.2f", v));
                g.drawString(font, s, right - font.width(s), cy - 4, rgba(0xB4B8D2, a), false);
            }
            default -> {
                String bl = r.btnSup != null ? r.btnSup.get() : Tr.tr(r.btn);
                int pw = Math.max(108, font.width(bl) + 18), x = right - pw, ph = 16, yy = cy - ph / 2;
                rrect(g, x, yy, pw, ph, 8, rgba(mix(0x2A2D44, accent, (hv || capturing != null && r.btnSup != null && bl.equals(Tr.tr("Press a key..."))) ? 0.45f : 0.22f), a));
                g.drawString(font, bl, x + (pw - font.width(bl)) / 2, yy + 4, rgba(0xFFFFFF, a), false);
            }
        }
    }

    private int sliderX() { return cx + cw - 10 - 150; }
    private int sliderW() { return 100; }

    // ---------- ввод ----------
    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        padMode = false;
        if (capturing != null) {
            bindCaptured(com.mojang.blaze3d.platform.InputConstants.Type.MOUSE.getOrCreate(btn));
            return true;
        }
        for (int i = 0; i < TABS.length; i++) {
            if (in(mx, my, px + 11, py + 42 + i * TAB_STEP, SIDE - 16, TAB_H)) {
                if (tab != i || openSub != null) { tab = i; openRow = null; openSub = null; resetPage(); }
                return true;
            }
        }
        if (in(mx, my, px + 11, py + H - 28, SIDE - 16, 18)) {
            Config.master = !Config.master;
            Config.save();
            return true;
        }
        if (openSub != null && btn == 0 && in(mx, my, cx, py + 9, 54, 18)) {
            closeSettings();
            return true;
        }
        if (my >= rtop && my < rbot) {
            List<Row> rows = cur();
            for (int j = 0; j < rows.size() && j < ys.length; j++) {
                if (!in(mx, my, cx, ys[j], cw, hs[j])) continue;
                Row r = rows.get(j);
                if (btn == 1 && r.sub != null) { openSettings(r); return true; }
                switch (r.type) {
                    case 0 -> {
                        if (btn == 1) return true;
                        if (r.sub != null && in(mx, my, gearX(), ys[j] + hs[j] / 2 - 7, 20, 14)) { openSettings(r); return true; }
                        r.bset.accept(!r.bget.getAsBoolean());
                    }
                    case 1 -> {
                        int n = r.names.length;
                        r.iset.accept(Math.floorMod(r.iget.getAsInt() + (btn == 1 ? -1 : 1), n));
                    }
                    case 2 -> {
                        if (btn != 0) return true;
                        dragging = r;
                        applySlider(r, mx);
                    }
                    default -> { if (btn == 0) r.action.run(); }
                }
                Config.save();
                return true;
            }
        }
        if (btn == 1 && openSub != null) { closeSettings(); return true; }
        return super.mouseClicked(mx, my, btn);
    }


    // ---------- геймпад ----------
    private void padFix() {
        List<Row> rows = cur();
        sel = Math.max(0, Math.min(rows.size() - 1, sel));
        int top = 0;
        for (int i = 0; i < sel; i++) top += rows.get(i).height();
        int bottom = top + rows.get(sel).height();
        int view = rbot - rtop;
        if (top < scrollTarget) scrollTarget = top;
        else if (bottom > scrollTarget + view) scrollTarget = bottom - view;
    }

    public void padMove(int d) {
        padMode = true;
        sel += d;
        padFix();
    }

    public void padAdjust(int d) {
        padMode = true;
        List<Row> rows = cur();
        if (sel < 0 || sel >= rows.size()) return;
        Row r = rows.get(sel);
        switch (r.type) {
            case 0 -> r.bset.accept(d > 0);
            case 1 -> r.iset.accept(Math.floorMod(r.iget.getAsInt() + d, r.names.length));
            case 2 -> {
                double step = r.isInt ? 1.0 : (r.max - r.min) / 20.0;
                double v = Math.max(r.min, Math.min(r.max, r.dget.getAsDouble() + d * step));
                r.dset.accept(r.isInt ? Math.round(v) : Math.round(v * 100.0) / 100.0);
            }
            default -> { return; }
        }
        Config.save();
    }

    public void padActivate() {
        padMode = true;
        List<Row> rows = cur();
        if (sel < 0 || sel >= rows.size()) return;
        Row r = rows.get(sel);
        switch (r.type) {
            case 0 -> r.bset.accept(!r.bget.getAsBoolean());
            case 1 -> r.iset.accept(Math.floorMod(r.iget.getAsInt() + 1, r.names.length));
            case 3 -> r.action.run();
            default -> { return; }
        }
        Config.save();
    }

    public void padSub() {
        padMode = true;
        List<Row> rows = cur();
        if (sel >= 0 && sel < rows.size() && rows.get(sel).sub != null) openSettings(rows.get(sel));
    }

    public void padBack() {
        padMode = true;
        if (openSub != null) closeSettings();
        else onClose();
    }

    public void padTab(int d) {
        padMode = true;
        tab = Math.floorMod(tab + d, TABS.length);
        openRow = null;
        openSub = null;
        resetPage();
    }

    public void padScroll(float amount) {
        scrollTarget += amount;
    }

    private void applySlider(Row r, double mx) {
        double f = Math.max(0, Math.min(1, (mx - sliderX()) / sliderW()));
        double v = r.min + f * (r.max - r.min);
        r.dset.accept(r.isInt ? Math.round(v) : Math.round(v * 100.0) / 100.0);
    }

    @Override
    public void mouseMoved(double mx, double my) {
        if (padMode && (Math.abs(mx - mouseX) > 2 || Math.abs(my - mouseY) > 2)) padMode = false;
        super.mouseMoved(mx, my);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragging != null) { applySlider(dragging, mx); return true; }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        if (dragging != null) { dragging = null; Config.save(); }
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        scrollTarget -= (float) (sy * 28);
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (capturing != null) {
            if (key == 256) capturing = null;
            else if (key == 259 || key == 261) bindCaptured(com.mojang.blaze3d.platform.InputConstants.UNKNOWN);
            else bindCaptured(com.mojang.blaze3d.platform.InputConstants.getKey(key, scan));
            return true;
        }
        if (key == 256 && openSub != null) { closeSettings(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
        // свой фон рисуется в render(), без размытия ванили
    }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
